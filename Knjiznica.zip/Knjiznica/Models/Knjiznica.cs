﻿namespace Knjiznica.Models
{
    public class Knjiznica
    {
    }
}
